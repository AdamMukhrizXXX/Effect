// ============================================================
// POKEDEX - FULL & RINGKAS (TypeScript)
// ============================================================

const { useState, useEffect, useCallback, useMemo, memo, useRef } = React;

// ===== TYPES =====
interface Pokemon {
  id: number;
  name: string;
  types: { slot: number; type: { name: string } }[];
  sprites: { front_default: string; other?: { 'official-artwork': { front_default: string } } };
}

// ===== UTILITIES =====
const typeColors: Record<string, string> = {
  normal:'#A8A878', fire:'#F08030', water:'#6890F0', electric:'#F8D030',
  grass:'#78C850', ice:'#98D8D8', fighting:'#C03028', poison:'#A040A0',
  ground:'#E0C068', flying:'#A890F0', psychic:'#F85888', bug:'#A8B820',
  rock:'#B8A038', ghost:'#705898', dragon:'#7038F8', dark:'#705848',
  steel:'#B8B8D0', fairy:'#EE99AC'
};
const typeClass = (t: string) => `bg-${t}`;
const padId = (id: number) => String(id).padStart(4, '0');
const getImg = (p: Pokemon) => p.sprites?.other?.['official-artwork']?.front_default || p.sprites?.front_default || '';

// ===== API =====
const fetchAll = async (cb?: (p: number) => void): Promise<Pokemon[]> => {
  const res = await fetch('https://pokeapi.co/api/v2/pokemon?limit=2000');
  const data = await res.json();
  const all: Pokemon[] = [];
  for (let i = 0; i < data.results.length; i += 20) {
    const batch = await Promise.all(data.results.slice(i, i + 20).map(async (p: any) => {
      const r = await fetch(p.url); return r.json();
    }));
    all.push(...batch);
    cb && cb(Math.min((i + 20) / data.results.length * 100, 100));
  }
  return all;
};

// ===== COMPONENTS =====
const TypeBadge = memo(({ type }: { type: string }) => (
  <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold text-white ${typeClass(type)}`}>{type}</span>
));

const PokemonCard = memo(({ pokemon, index }: { pokemon: Pokemon; index: number }) => {
  const [loaded, setLoaded] = useState(false);
  const [hover, setHover] = useState(false);
  const color = typeColors[pokemon.types?.[0]?.type?.name] || '#A8A878';
  
  return (
    <div className={`card-hover relative rounded-2xl overflow-hidden animate-fade-in`}
         style={{ animationDelay: `${(index % 20) * 30}ms`, background: `${color}15` }}
         onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div className="relative pt-3 px-3">
        <div className="relative aspect-square">
          {!loaded && <div className="absolute inset-0 bg-gray-200 rounded-xl shimmer"></div>}
          <img src={getImg(pokemon)} alt={pokemon.name} loading="lazy"
               className={`w-full h-full object-contain transition-all duration-500 ${loaded ? 'opacity-100' : 'opacity-0'} ${hover ? 'scale-105' : 'scale-100'}`}
               onLoad={() => setLoaded(true)} />
        </div>
      </div>
      <div className="p-3 pt-0">
        <div className="flex justify-between items-start mb-1">
          <h3 className="text-sm font-bold text-gray-800 capitalize truncate">{pokemon.name}</h3>
          <span className="text-[10px] text-gray-500">#{padId(pokemon.id)}</span>
        </div>
        <div className="flex flex-wrap gap-1">
          {pokemon.types?.map(t => <TypeBadge key={t.slot} type={t.type.name} />)}
        </div>
      </div>
    </div>
  );
});

// ===== LOADING SCREEN =====
const LoadingScreen = ({ progress }: { progress: number }) => (
  <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
    <div className="text-center">
      <div className="pokeball mx-auto mb-6"><div className="center-line"></div></div>
      <h1 className="text-3xl font-bold text-gray-800 mb-2">Loading Pokédex</h1>
      <p className="text-gray-500 text-sm mb-4">
        {progress < 30 ? 'Connecting...' : progress < 60 ? 'Fetching data...' : progress < 90 ? 'Processing...' : 'Almost ready!'}
      </p>
      <div className="w-64 h-2 bg-gray-200 rounded-full overflow-hidden mx-auto">
        <div className="h-full bg-gradient-to-r from-red-500 to-red-600 rounded-full transition-all duration-300"
             style={{ width: `${progress}%` }} />
      </div>
      <p className="text-sm text-gray-400 mt-2">{Math.round(progress)}%</p>
    </div>
  </div>
);

// ===== SEARCH BAR =====
const SearchBar = ({ onSearch, loading, total }: { onSearch: (t: string) => void; loading: boolean; total: number }) => {
  const [term, setTerm] = useState('');
  const [focus, setFocus] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  const timeout = useRef<NodeJS.Timeout>();

  useEffect(() => {
    clearTimeout(timeout.current);
    timeout.current = setTimeout(() => onSearch(term), 300);
    return () => clearTimeout(timeout.current);
  }, [term]);

  return (
    <div className="relative max-w-2xl mx-auto">
      <div className={`relative transition-all duration-300 ${focus ? 'scale-105' : 'scale-100'}`}>
        <div className="relative flex items-center bg-white rounded-full shadow-lg overflow-hidden border-2 border-red-200 focus-within:border-red-500">
          <svg className="absolute left-4 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input ref={ref} type="text" value={term} onChange={(e) => setTerm(e.target.value)}
                 onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
                 placeholder={`Search ${total || '2000+'} Pokémon...`}
                 className="w-full py-3 pl-12 pr-12 bg-transparent outline-none text-gray-700" disabled={loading} />
          {term && <button onClick={() => { setTerm(''); ref.current?.focus(); }}
                           className="absolute right-4 p-1 rounded-full hover:bg-gray-100">✕</button>}
        </div>
      </div>
    </div>
  );
};

// ===== PAGINATION =====
const Pagination = ({ page, total, onChange }: { page: number; total: number; onChange: (p: number) => void }) => {
  const pages: number[] = [];
  const max = 5;
  if (total <= max) { for (let i = 1; i <= total; i++) pages.push(i); }
  else if (page <= 3) { for (let i = 1; i <= max; i++) pages.push(i); }
  else if (page >= total - 2) { for (let i = total - max + 1; i <= total; i++) pages.push(i); }
  else { for (let i = page - 2; i <= page + 2; i++) pages.push(i); }

  return (
    <div className="flex flex-wrap justify-center items-center gap-2 mt-6">
      <button onClick={() => onChange(1)} disabled={page === 1}
              className="px-3 py-1.5 rounded-lg bg-white shadow hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 text-sm">⏮</button>
      <button onClick={() => onChange(page - 1)} disabled={page === 1}
              className="px-3 py-1.5 rounded-lg bg-white shadow hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105">←</button>
      {pages.map(p => (
        <button key={p} onClick={() => onChange(p)}
                className={`px-3 py-1.5 rounded-lg transition hover:scale-105 ${page === p ? 'bg-red-500 text-white shadow-lg' : 'bg-white shadow hover:shadow-lg'}`}>{p}</button>
      ))}
      <button onClick={() => onChange(page + 1)} disabled={page === total}
              className="px-3 py-1.5 rounded-lg bg-white shadow hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105">→</button>
      <button onClick={() => onChange(total)} disabled={page === total}
              className="px-3 py-1.5 rounded-lg bg-white shadow hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 text-sm">⏭</button>
    </div>
  );
};

// ===== MAIN APP =====
const App = () => {
  const [all, setAll] = useState<Pokemon[]>([]);
  const [display, setDisplay] = useState<Pokemon[]>([]);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [total, setTotal] = useState(0);
  const PER_PAGE = 50;

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true); setError(null); setProgress(0);
        const data = await fetchAll((p) => setProgress(p));
        setAll(data); setTotal(data.length);
        setDisplay(data.slice(0, PER_PAGE));
      } catch (e) { setError('Failed to load Pokemon.'); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const handleSearch = useCallback((term: string) => {
    setSearch(term);
    const results = term?.trim() ? all.filter(p =>
      p.name.toLowerCase().includes(term.toLowerCase()) ||
      String(p.id).includes(term)
    ) : all;
    setDisplay(results.slice(0, PER_PAGE));
    setTotal(results.length);
    setPage(1);
  }, [all]);

  const handlePage = useCallback((newPage: number) => {
    const start = (newPage - 1) * PER_PAGE;
    const data = search?.trim() ? all.filter(p =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      String(p.id).includes(search)
    ) : all;
    setDisplay(data.slice(start, start + PER_PAGE));
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [all, search]);

  const totalPages = useMemo(() => Math.ceil(total / PER_PAGE), [total]);
  const info = useMemo(() => {
    if (!total) return { start: 0, end: 0 };
    const start = (page - 1) * PER_PAGE + 1;
    return { start, end: Math.min(page * PER_PAGE, total) };
  }, [page, total]);

  if (loading && !all.length) return <LoadingScreen progress={progress} />;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="bg-gradient-to-r from-red-600 to-red-700 text-white py-6 shadow-lg">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <span className="text-4xl">⚡</span>
            <h1 className="text-4xl font-bold">Pokédex</h1>
            <span className="text-4xl">✨</span>
          </div>
          <p className="text-red-100 text-sm mb-4">{total || '2000+'} Pokémon Database</p>
          <SearchBar onSearch={handleSearch} loading={loading} total={total} />
        </div>
      </div>

      <div className="container mx-auto px-4 py-4">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl mb-4 text-center">
            {error} <button onClick={() => window.location.reload()} className="ml-3 px-4 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600">Retry</button>
          </div>
        )}

        {!loading && !error && total > 0 && (
          <div className="glass rounded-xl p-3 mb-4 flex flex-wrap justify-between items-center text-sm">
            <span>Showing <b>{info.start}</b> - <b>{info.end}</b> of <b className="text-red-600">{total}</b></span>
            <span>Page <b>{page}</b> of <b>{totalPages}</b></span>
          </div>
        )}

        {!loading && !error && (
          <>
            <div className="pokemon-grid">
              {display.length ? display.map((p, i) => <PokemonCard key={p.id} pokemon={p} index={i} />)
                : Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="rounded-2xl bg-gray-200/50 shimmer" style={{ height: '200px' }}></div>
                ))}
            </div>

            {!display.length && !loading && (
              <div className="text-center py-20">
                <div className="text-5xl mb-4">🔍</div>
                <p className="text-gray-500 text-lg">No Pokémon found</p>
              </div>
            )}

            {totalPages > 1 && <Pagination page={page} total={totalPages} onChange={handlePage} />}
            <div className="text-center mt-6 text-xs text-gray-400">✨ {total} Pokémon loaded</div>
          </>
        )}
      </div>
    </div>
  );
};

// ===== RENDER =====
try {
  ReactDOM.createRoot(document.getElementById('root')).render(<App />);
} catch (e: any) {
  document.getElementById('root')!.innerHTML = `
    <div style="padding:40px;text-align:center;background:#f0f4ff;min-height:100vh;display:flex;flex-direction:column;justify-content:center;">
      <div style="font-size:48px;">⚠️</div>
      <h2 style="color:#dc2626;">Error</h2>
      <p style="color:#6b7280;">${e.message}</p>
      <button onclick="location.reload()" style="margin-top:20px;padding:10px 30px;background:#ef4444;color:white;border:none;border-radius:10px;cursor:pointer;">Refresh</button>
    </div>
  `;
}