# ⚡ Pokédex - Complete Pokémon Database

A beautiful and fast Pokédex application that displays all 2000+ Pokémon from the PokeAPI.

![Pokédex](https://img.shields.io/badge/Pokédex-React-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## ✨ Features

- 🎯 **2000+ Pokémon** - Complete database from PokeAPI
- 🔍 **Real-time Search** - Search by name or ID
- 📄 **Pagination** - 50 Pokémon per page
- 🎨 **Beautiful UI** - Clean and modern design
- 📱 **Responsive** - Works on all devices
- ⚡ **Fast Loading** - Optimized performance
- 🎮 **Pokeball Loading** - Animated loading screen

## 🚀 Quick Start

### 1. Clone or Download
```bash
git clone https://github.com/AdamMukhrizXXX/Effect.git